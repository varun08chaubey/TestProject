package generic;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import Utilities.ReadConfig;





public class Base_Class {

	

		//ReadConfig readConfig = new ReadConfig();
		
		
		
		public static WebDriver driver3;		// Used for selenium browser driver.
		public static boolean start_thread_main=false;
		public static String chromeDriverPath = System.getProperty("user.dir") + "\\drivers\\chromedriver.exe";
		//public String deviceName = readConfig.getDeviceName();
		public static ExtentReports extent;
		public static ExtentTest test;
		public static String msg_time_stamp=null;
		
		ReadConfig config = new ReadConfig();
		
		public String Browser = config.browser_selection();

		//private static AppiumDriverLocalService server;
		
		
		/*
		 * Starting Appium Server programmatically
		 */

		
		

			


				// capture screenshots
		public static String captureScreen(WebDriver driver, String tname) throws IOException {
			TakesScreenshot ts = (TakesScreenshot) driver;
			File source = ts.getScreenshotAs(OutputType.FILE);
			File target = new File(System.getProperty("user.dir") + "/screenshots/" + tname + ".png");
			FileUtils.copyFile(source, target);
			//System.out.println("Screenshot taken");
			return tname;
		}

		// screenshot for extent report
		public static String captureScreenExtent(WebDriver driver, String screenshotname) throws IOException {
			TakesScreenshot ts = (TakesScreenshot) driver;
			File source = ts.getScreenshotAs(OutputType.FILE);
			String dest = System.getProperty("user.dir") + "/screenshots/" + screenshotname + ".png";
			File destination = new File(dest);
			FileUtils.copyFile(source, destination);
			return dest;
		}
		
		//video log capture 
		public static String captureVideoLog(WebDriver driver, String videoLogname) throws IOException {
			TakesScreenshot ts = (TakesScreenshot) driver;
			File source = ts.getScreenshotAs(OutputType.FILE);
			String dest_video = System.getProperty("user.dir") + "/video-log/" + videoLogname + ".mp4";
			File destination = new File(dest_video);
			FileUtils.copyFile(source, destination);
			return dest_video;
		}

	

	

		// webApp driver
		public WebDriver getDriver(String browser2) {

		

			
				System.setProperty("webdriver.chrome.driver", chromeDriverPath);
				 driver3 = new ChromeDriver();
				return driver3;
		}

		
		// implicit wait
		public void Implicitwait() {
			driver3.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		}

		/*
		 * PageObject pob= new PageObject(driver);
		 * ExplicitwaitBrowser(PageClassObj.Locatorname, 5);
		 */

		// explict wait
		public void ExplicitwaitBrowser(WebElement ele, long T1) {
			WebDriverWait wait = new WebDriverWait(driver3, T1);
			wait.until(ExpectedConditions.visibilityOf(ele)).isDisplayed();
		}

		// close resources
		public void tearDown() {
			if( driver3 != null ) {
				driver3.quit();
			} 
		}

		// web app launcher
		public void Launch_WebApp() {
			System.setProperty("webdriver.chrome.driver", chromeDriverPath);
			 driver3 = new ChromeDriver();
			driver3.get(ReadConfig.getPropertiesdata("URL"));
			driver3.manage().window().maximize();
		}


		
		
	    public static boolean is_Element_Present(WebDriver driver , WebElement element,int duration) throws InterruptedException {
	    	
	    	WebDriverWait webDriverWait = new WebDriverWait(driver,duration);
	    	Thread.sleep(3000);
	    	WebElement Present=webDriverWait.until(ExpectedConditions.visibilityOf(element));
	    	if(Present.isDisplayed()) {
	    		
	    		return true;
	    		
	    	}
	    	else {
	    		
	    		return false;
	    	}
	    }
	    
	    public static void  Navigate (WebDriver driver , WebElement element,int duration) throws InterruptedException {
	    	//boolean User_Present=Base_Class.is_Element_Present(driver,element,duration) ;
	    	WebDriverWait webDriverWait = new WebDriverWait(driver,duration);
	    	Thread.sleep(3000);
	    	WebElement PresentElement=webDriverWait.until(ExpectedConditions.visibilityOf(element));
	    	if(PresentElement.isDisplayed()){
				if(PresentElement.isEnabled()) {
					PresentElement.click();
				}
				else {
					JavascriptExecutor executor = (JavascriptExecutor)driver;
					executor.executeScript("arguments[0].click();", PresentElement);
				}
	    	
	    	}
			
			
	    }
	    
	    public static void  dataentry (WebDriver driver , WebElement element,String testdata,int duration) throws InterruptedException {
	    	
	    	WebDriverWait webDriverWait = new WebDriverWait(driver,duration);
	    	WebElement PresentElement=webDriverWait.until(ExpectedConditions.visibilityOf(element));
	    	Thread.sleep(3000);
	    	PresentElement.sendKeys(testdata);
			
	    }
	    
	    
	    public static void  select (WebDriver driver , WebElement element,String testdata,int duration) throws InterruptedException {
	    	//element=driver.findElement(By.xpath("//div[@id='uniform-id_state']/select"));
	    	//WebDriverWait webDriverWait = new WebDriverWait(driver,duration);
	    	//WebElement PresentElement=webDriverWait.until(ExpectedConditions.visibilityOf(element));
	    	Thread.sleep(3000);
	    	element.click();
	    	Select sc=new Select(element);
	    	sc.selectByVisibleText(testdata);
	    	
	    	
	    }
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    public static void  frame_dataentry (WebDriver driver , WebElement element,String testdata,int duration) throws InterruptedException {
	    	
	    	
	    	WebDriverWait webDriverWait = new WebDriverWait(driver,duration);
	    	WebElement PresentElement=webDriverWait.until(ExpectedConditions.visibilityOf(element));
	    	driver.switchTo().frame(PresentElement);
	    	Thread.sleep(3000);
	    	driver.findElement(By.id("tinymce")).click();
	    	driver.findElement(By.id("tinymce")).sendKeys(testdata);
	    	driver.switchTo().defaultContent();
	    	
	    }
	    
	    
	    
	    
	    
	  
		public byte[] saveFailureScreenShot(WebDriver driver) {
			return ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
		}

	    
	    // return  current time 
	    
	    public static String Msg_Time() {
			
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				Date date = new Date();
				String value = dateFormat.format(date);
				String FinalValue = value.replaceFirst(" ", "_");
				
				// System.out.println(FinalValue);
				String actValue = FinalValue.replace(":", "_");
				
				// System.out.println(actValue);
				String filename = "File";
				String File = filename + "_" + actValue;
				return File;
				
		}


	}

	
	
	
	
	

