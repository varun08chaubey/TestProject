package testcases;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;

import Utilities.ExtentManager;
import Utilities.ReadConfig;
import pageobject.HomePage;

public class Login extends  generic.Base_Class {
  @Test
  
  public void Login_test() throws IOException {
	  try {
		  boolean present =false;
		  Launch_WebApp();
		  
		  extent = ExtentManager.GetExtent();
		  test = extent.createTest("Login Test", "With valid credential user should login successfully");
		  HomePage homepage=PageFactory.initElements(driver3, HomePage.class);
		  
		//home page opration
		  Navigate(driver3,homepage.sign_in,8000);
		  dataentry(driver3,homepage.email_id_Login,ReadConfig.getPropertiesdata("email"),8000);
		  dataentry(driver3,homepage.password_Login,ReadConfig.getPropertiesdata("Password"),8000);
		  Navigate(driver3,homepage.SubmitLogin,8000);
		  present=is_Element_Present(driver3,homepage.Logout,8000);
		  if(present==true) {
			  String LoginSuccessful = generic.Base_Class.captureScreenExtent(driver3, "Login is successful");
			  test.log(Status.PASS, "Login is successful",  MediaEntityBuilder.createScreenCaptureFromPath(LoginSuccessful).build());
			  extent.flush();
			  driver3.quit();
		  }
		  else {
			  String LoginNotSuccessful = generic.Base_Class.captureScreenExtent(driver3, "Login is not successful");
			  test.log(Status.FAIL, "Login is not successful",  MediaEntityBuilder.createScreenCaptureFromPath(LoginNotSuccessful).build());
			  extent.flush();
			  driver3.quit();
			  
		  }
		  
	  
	  
  }catch (Exception e) {
		
	  
		String screenshot_4 = generic.Base_Class.captureScreenExtent(driver3, "Error occured while Login");
		test.fail("Login failed", MediaEntityBuilder.createScreenCaptureFromPath(screenshot_4).build());
		test.log(Status.FAIL, "Test case - FAILED");
		test.log(Status.ERROR, e.getMessage());
		extent.flush();
		driver3.quit();

		
	}
  }
	  
  
  
  
  
  
  
  
  
  
  
  
  
  
}
