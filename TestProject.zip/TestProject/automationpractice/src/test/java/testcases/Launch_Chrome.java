package testcases;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.Markup;

import Utilities.ReadConfig;

import pageobject.HomePage;
import pageobject.registration;
import Utilities.ExtentManager;



public class Launch_Chrome extends generic.Base_Class {
  @Test
 
  public void  launch_browser() throws InterruptedException, IOException {
	  
	  try {
	  Launch_WebApp();
	  
	  extent = ExtentManager.GetExtent();
	  test = extent.createTest("Registration Test", "User is registring first time");
	  
	  HomePage homepage=PageFactory.initElements(driver3, HomePage.class);
	  registration reg=PageFactory.initElements(driver3, registration.class);
	  
	  //home page opration
	  Navigate(driver3,homepage.sign_in,8000);
	  dataentry(driver3,homepage.email_id,ReadConfig.getPropertiesdata("email"),8000);
	  
	  Navigate(driver3,homepage.Create_Account,8000);
	  
	  String email_accepted = generic.Base_Class.captureScreenExtent(driver3, "Email is accepted");
	  test.log(Status.PASS, "Email is accepted successfully",  MediaEntityBuilder.createScreenCaptureFromPath(email_accepted).build());
	  
	  // registration page operation
	  Navigate(driver3,reg.title,8000);
	  dataentry(driver3,reg.firstName,ReadConfig.getPropertiesdata("First_Name"),8000);
	  dataentry(driver3,reg.lastName,ReadConfig.getPropertiesdata("Last_Name"),8000);
	  dataentry(driver3,reg.password,ReadConfig.getPropertiesdata("Password"),8000);
	  dataentry(driver3,reg.address1,ReadConfig.getPropertiesdata("Add1"),8000);
	  dataentry(driver3,reg.Mobile_phone,ReadConfig.getPropertiesdata("Mobile"),8000);
	  dataentry(driver3,reg.city,ReadConfig.getPropertiesdata("City"),8000);
	  dataentry(driver3,reg.PinCode,ReadConfig.getPropertiesdata("PinCode"),8000);
	  
	  //select(driver3,reg.Select_Country,ReadConfig.getPropertiesdata("Country"),8000);
	  
	  select(driver3,reg.Select_State,ReadConfig.getPropertiesdata("state"),8000);
	  
	  
	  String Reg_Form = generic.Base_Class.captureScreenExtent(driver3, "Details Entered in the registration form");
	  test.log(Status.PASS, "Registration form is filled successfully with user details.",  MediaEntityBuilder.createScreenCaptureFromPath(Reg_Form).build());
	 
	 
	  
	  Navigate(driver3,reg.register,8000);
	  
	  String Reg_Complete = generic.Base_Class.captureScreenExtent(driver3, "Registration Completed!");
	  test.log(Status.PASS, "Registration Completed!",  MediaEntityBuilder.createScreenCaptureFromPath(Reg_Complete).build());
	  
	  
	
	  
	  }catch (Exception e) {
			
		  
			String screenshot_3 = generic.Base_Class.captureScreenExtent(driver3, "Error occured while registering new user");
			test.fail("Verification failed", MediaEntityBuilder.createScreenCaptureFromPath(screenshot_3).build());
			test.log(Status.FAIL, "Test case - FAILED");
			test.log(Status.ERROR, e.getMessage());
			extent.flush();
			driver3.quit();

			
		}
		
		
		//softassert.assertAll();
		extent.flush();
		driver3.quit();

	  
	  
	  
  }
}
