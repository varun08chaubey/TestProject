package pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class HomePage {

	public static WebDriver driver;
	
	public HomePage(WebDriver driver) {
		this.driver=driver;
	}
	
	
	@CacheLookup
	@FindBy(xpath = "//a[contains(text(),'Sign in')]")
	public WebElement sign_in;
	
		
	@CacheLookup
	@FindBy(xpath = "//input[@id='email_create']")
	public WebElement email_id;
		
	@CacheLookup
	@FindBy(xpath = "//button[@id='SubmitCreate']")
	public WebElement Create_Account;
	
	// *********************** Login related web element****************************************8
	
	
	
	
	@CacheLookup
	@FindBy(xpath = "//input[@id='email']")
	public WebElement email_id_Login;
	
	
	
	@CacheLookup
	@FindBy(xpath = "//input[@id='passwd']")
	public WebElement password_Login;
	
	
	//button[@id='SubmitLogin']
		
	
	@CacheLookup
	@FindBy(xpath = "//button[@id='SubmitLogin']")
	public WebElement SubmitLogin;
	

	@CacheLookup
	@FindBy(xpath = "//div[@class='header_user_info']/a[contains(text(),'Sign out')]")
	public WebElement Logout;
	
	
	//***********************************************Cart Test*******************************************
	
	@CacheLookup
	@FindBy(xpath = "//ul[@class='sf-menu clearfix menu-content sf-js-enabled sf-arrows']/li[3]/a")
	public WebElement Tshirt;
	
	
	@CacheLookup
	@FindBy(xpath = "//img[@alt='Faded Short Sleeve T-shirts']")
	public static  WebElement ShortTshirtBuy;
	
	
	//a[@title='Add to cart']
	
	@CacheLookup
	@FindBy(xpath = "//a[@title='Add to cart']")
	public static WebElement AddCart;
	
	
	
	
	@CacheLookup
	@FindBy(xpath = "//span[@title='Close window']/following-sibling::h2")
	public static WebElement ProductInCart;
	
	
	
	public static   void mouse_hover(WebElement element) {
		
		Actions ac=new Actions(driver);
		
		
		ac.moveToElement(element).click(AddCart).perform();
		
		
		
		
		
	}
	

	public static void clickAndHold(WebElement element) {
		
	}
	
	
	
	
	
	
	
	
	
	
	
}
