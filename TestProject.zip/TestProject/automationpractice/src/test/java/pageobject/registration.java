package pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class registration {
	
	public static WebDriver driver;
	
	public registration(WebDriver driver) {
		this.driver=driver;
	}
	
	
	@CacheLookup
	@FindBy(xpath = "//label[contains(text(),'Title')]/following-sibling::div[1]//div[@class='radio']")
	public WebElement title;
	
	
	//input[@id='customer_firstname']
	
	
	@CacheLookup
	@FindBy(xpath = "//input[@id='customer_firstname']")
	public WebElement firstName;
	
	@CacheLookup
	@FindBy(xpath = "//input[@id='customer_lastname']")
	public WebElement lastName;
	
	
	
	
	
	
	@CacheLookup
	@FindBy(xpath = "//input[@id='passwd']")
	public WebElement password;
	
	
	@CacheLookup
	@FindBy(xpath = "//input[@id='address1']")
	public WebElement address1;
	
	
	
	@CacheLookup
	@FindBy(xpath = "//input[@id='city']")
	public WebElement city;
	
	
	
	
	@CacheLookup
	@FindBy(xpath = "//input[@id='postcode']")
	public WebElement PinCode;
	
	
	
	
	
	@CacheLookup
	@FindBy(xpath = "//input[@id='phone_mobile']")
	public WebElement Mobile_phone;
	
	
	
	
	
	@CacheLookup
	@FindBy(xpath = "//select[@id='id_state']")
	public WebElement Select_State;
	
	
	@CacheLookup
	@FindBy(xpath = "//select[@id='id_country']")
	public WebElement Select_Country;
	
	
	
	
	@CacheLookup
	@FindBy(xpath = "//button[@id='submitAccount']")
	public WebElement register;
	
	
	
	
	
	
}
