package Utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ReadConfig {

	public Properties pro;

	public ReadConfig() {
		File src = new File("./configuration/config.properties");

		try {
			FileInputStream fis = new FileInputStream(src);
			pro = new Properties();
			try {
				pro.load(fis);
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			System.out.println("Exception is" + e.getMessage());
			e.printStackTrace();
		}
	}

	

	
	public String browser_selection() {
		String gmail = pro.getProperty("Browser");
		return gmail;

	}	
	
	
	
	
	
	public static String getPropertiesdata(String propery) {
		Properties properties = new Properties();
		// load a properties file from class path, inside static method
		try {
			properties.load(new FileInputStream("configuration/config.properties"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String Prop_data = properties.getProperty(propery);
		return Prop_data;
	}




}